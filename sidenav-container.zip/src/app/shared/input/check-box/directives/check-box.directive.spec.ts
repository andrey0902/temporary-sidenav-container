import { CheckBoxDirective } from './check-box.directive';

describe('CheckBoxDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckBoxDirective();
    expect(directive).toBeTruthy();
  });
});
