import { SlideCheckboxDirective } from './slide-checkbox.directive';

describe('SlideCheckboxDirective', () => {
  it('should create an instance', () => {
    const directive = new SlideCheckboxDirective();
    expect(directive).toBeTruthy();
  });
});
