export interface OptionModel {
  value: any;
  label: string;
}
