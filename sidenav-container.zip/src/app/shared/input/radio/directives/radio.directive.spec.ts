import { RadioDirective } from './radio.directive';

describe('RadioDirective', () => {
  it('should create an instance', () => {
    const directive = new RadioDirective();
    expect(directive).toBeTruthy();
  });
});
