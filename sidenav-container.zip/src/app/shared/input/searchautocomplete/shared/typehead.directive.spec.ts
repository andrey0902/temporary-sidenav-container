import { TypeheadDirective } from './typehead.directive';

describe('TypeheadDirective', () => {
  it('should create an instance', () => {
    const directive = new TypeheadDirective();
    expect(directive).toBeTruthy();
  });
});
