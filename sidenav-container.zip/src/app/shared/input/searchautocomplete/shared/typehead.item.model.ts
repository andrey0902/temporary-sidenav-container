export interface TypeheadItemModel {
  item: TypeheadData | any;
}

interface TypeheadData {
  name: string;
}
