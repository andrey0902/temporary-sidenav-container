export interface ErrorMessageModel {
  [key: string ]: (params?) => string;
}
