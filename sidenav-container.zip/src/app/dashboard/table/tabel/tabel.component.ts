import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabel',
  templateUrl: './tabel.component.html',
  styleUrls: ['./tabel.component.scss']
})
export class TabelComponent implements OnInit {
  displayedColumns = ['seqNo', 'description', 'duration'];
  constructor() { }

  ngOnInit() {
  }

  onRowClicked(e) {
    console.log('click on row', e);
  }

}
