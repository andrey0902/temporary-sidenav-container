import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule,
  MatTableModule
} from '@angular/material';
import { TabelComponent } from './tabel/tabel.component';

@NgModule({
  declarations: [
    TabelComponent
  ],
  imports: [
    CommonModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule
  ],
  exports: [
    TabelComponent
  ]
})
export class TableModule { }
