import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { fromPromise } from 'rxjs/internal/observable/fromPromise';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private af: AngularFireAuth) { }

  createUser(email: string, password: string) {
    return fromPromise(
      this.af.auth.createUserWithEmailAndPassword(email, password)
    );
  }

  loginUser(email: string, password: string) {
    return fromPromise(
      this.af.auth.signInWithEmailAndPassword(email, password)
    );
  }
}
