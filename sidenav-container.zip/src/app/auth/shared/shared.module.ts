import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthFormComponent } from './auth-form/auth-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { InputModule } from '../../shared/input/input.module';
import { AngularFireAuthModule } from '@angular/fire/auth';

@NgModule({
  declarations: [AuthFormComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    InputModule,

    AngularFireAuthModule,
  ],
  exports: [
    AuthFormComponent
  ]
})
export class SharedModule { }
