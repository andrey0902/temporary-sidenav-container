import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AuthService } from '../shared/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  serverError = null;
  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  onSubmit(e: FormGroup) {
    console.log(e.value);
    const { email, password } = e.value;
    this.authService.createUser(email, password)
      .subscribe((result) => {
        console.log('user create', result);
        this.serverError = null;
      }, error => {
        this.serverError = error.message;
        console.log('user create error', error);
      });
  }

}
