import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Store } from './store';
import { AuthModule } from './auth/auth.module';

import { AngularFireModule, FirebaseAppConfig } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { environment } from '../environments/environment';
import { SharedModule } from './auth/shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AuthModule,

    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAuthModule,
    AngularFireDatabaseModule,

    SharedModule,

    BrowserAnimationsModule,
  ],
  providers: [
    Store
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

/*
  var config = {
    apiKey: "AIzaSyC4XceDfe_LuSe1JmT36NXfLgff1g3PAys",
    authDomain: "fitnes-app-3cb44.firebaseapp.com",
    databaseURL: "https://fitnes-app-3cb44.firebaseio.com",
    projectId: "fitnes-app-3cb44",
    storageBucket: "fitnes-app-3cb44.appspot.com",
    messagingSenderId: "106577709177"
  };
* */
