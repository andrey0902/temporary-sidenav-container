export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyC4XceDfe_LuSe1JmT36NXfLgff1g3PAys',
    authDomain: 'fitnes-app-3cb44.firebaseapp.com',
    databaseURL: 'https://fitnes-app-3cb44.firebaseio.com',
    projectId: 'fitnes-app-3cb44',
    storageBucket: 'fitnes-app-3cb44.appspot.com',
    messagingSenderId: '106577709177'
  }
};
